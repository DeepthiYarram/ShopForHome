export class User{
    userFirstName!:string;
    userLastName!:string;
    userName!:string;
    userPassword!:string;
    emailId!:string;
    phoneNumber!:string;
}